function GetRandomNum(){
    let step1 = Math.random();
    
    console.log(step1);
    let step2 = step1 * 100;
    
    console.log(step2);
    let step3 = step2 + 1;
    
    console.log(step3);
    const rand=Math.floor(step3);
    
    console.log(rand);
    return rand;
}
function randomize(){
    const count = document.getElementById('count');
    count.innerText = GetRandomNum();
}

const coords = document.getElementById('coords');
coords.onmousemove = (event) => {
    console.log(event.offsetX);
    coords.innerText = `X = ${event.offsetX}, Y = ${event.offsetY}`
}
coords.onclick = () => {
    console.log("Left!");
}
coords.oncontextmenu = (e) => {
// e.preventDefault();
console.log("Right!");
}


function ShowHide(){
    const item = document.getElementById('ShowHide');
    if(item.style.display !== 'none'){
        item.style.display = 'none';
    }
    else{
        item.style.display = 'block';
    }
}