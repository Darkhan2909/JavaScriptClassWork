function clickme(){
    console.log("hello world!");
    // ex1
    // event.preventDefault();
    // console.log(event);
    // ex2
    event.stopPropagation();
}
const button = document.getElementById('button1');
button.addEventListener('click',clickme);